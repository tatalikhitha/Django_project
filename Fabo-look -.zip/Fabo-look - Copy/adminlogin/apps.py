from django.apps import AppConfig


class AdminloginConfig(AppConfig):
    name = 'adminlogin'
